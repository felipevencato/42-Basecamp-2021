Novo comando que descobri. Parecido com truncate
fallocate