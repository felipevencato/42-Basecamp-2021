void	ft_putchar (char c);
void	ft_print_alphabet (void);
void	ft_print_reverse_alphabet (void);
void	ft_print_numbers (void);
void	ft_is_negative (int n);
void	ft_print_comb (void);
void	ft_print_comb2 (void);
void	ft_putnbr (int nb);
void	ft_print_combn(int n);

int	main (int argc, char **argv)
{
	if (argc == 2)
	{
		if (argv[1][0] == '0')
			ft_putchar ('a');
		if (argv[1][0] == '1')
			ft_print_alphabet ();
		if (argv[1][0] == '2')
			ft_print_reverse_alphabet ();
		if (argv[1][0] == '3')
			ft_print_numbers ();
		if (argv[1][0] == '4')
		{
			ft_is_negative (0);
			ft_is_negative (1);
			ft_is_negative (-1);
		}
		if (argv[1][0] == '5')
			ft_print_comb ();
		if (argv[1][0] == '6')
			ft_print_comb2 ();
		if (argv[1][0] == '7')
		{
			ft_putnbr (42);
			ft_putchar ('\n');
			ft_putnbr (200);
			ft_putchar ('\n');
			ft_putnbr (2147483647);
			ft_putchar ('\n');
			ft_putnbr (-2147483648);
		}
		if (argv[1][0] == '8')
		{
			ft_print_combn(2);
			ft_putchar ('\n');
			ft_print_combn(4);
		}
	}
	return (0);
}
