#include <unistd.h>
void	ft_print (char *txt)
{
	if (txt[0] != txt[1] && txt[0] != txt[2] && txt[1] != txt[2])
	{
		write (1, txt, 3);
		if (txt[0] + txt[1] + txt[2] != '7' + '8' + '9')
			write (1, ", ", 2);
	}
}

void	ft_print_comb (void)
{
	char	txt[3];

	txt[0] = '0' - 1;
	while (txt[0] <= '7')
	{
		txt[1] = ++txt[0];
		while (txt[1] <= '8')
		{
			txt[2] = ++txt[1];
			while (txt[2] <= '9')
			{
				ft_print (txt);
				txt[2]++;
			}
		}
	}
}
