#include <unistd.h>
void	print_int_8 (char c)
{
	c += '0';
	write (1, &c, 1);
}

int	recursive (int nb)
{
	if (nb < 10)
		return (nb);
	else
		print_int_8(recursive(nb / 10));
	return (nb % 10);
}

int	recursive2 (int nb)
{
	if (nb < 10)
		return (nb - 1);
	print_int_8(recursive2(nb / 10));
	return (nb % 10);
}

void	ft_print_combn(int n)
{
	int	max;

	max = 1;
	while (n--)
		max *= 10;
	print_int_8(recursive2 (max));
}
