#include <unistd.h>
void	print_digit (char c)
{
	c += '0';
	write (1, &c, 1);
}

void	ft_putnbr (int nb)
{
	unsigned int number;

	number = nb;
	if (nb < 0)
		write (1, "-", 1);
	if (number < 10)
		return print_digit(number % 10);
	ft_putnbr(number / 10);
	print_digit(number % 10);
}

int	main (void)
{
	ft_putnbr (42);
	write (1, "\n", 1);
	ft_putnbr (200);
	write (1, "\n", 1);
	ft_putnbr (2147483647);
	write (1, "\n", 1);
	ft_putnbr (-2147483648);
	return (0);
}