#include <stdio.h>
#include <stdlib.h>
void	ft_ft (int *nbr);
void	ft_ultimate_ft (int *********nbr);
void	ft_swap (int *a, int *b);
void	ft_div_mod (int a, int b, int *div, int *mod);
void	ft_ultimate_div_mod (int *a, int *b);
void	ft_putstr (char *str);
int		ft_strlen (char *str);
void	ft_rev_int_tab (int *tab, int size);
void	ft_sort_int_tab (int *tab, int size);

void	run_ex (int option)
{
	printf("EX%d\n", option);
	switch (option)
	{
		case 0:
		{
			int	value = 0;
			ft_ft(&i);
			printf ("%d", value);
			break;
		}
		case 1:
		{
			int value = 24;
			int *p1 = &value;
			int **p2 = &p1;
			int ***p3 = &p2;
			int ****p4 = &p3;
			int *****p5 = &p4;
			int ******p6 = &p5;
			int *******p7 = &p6;
			int ********p8 = &p7;
			int	*********nbr = &p8;
			ft_ultimate_ft(nbr);
			printf ("%d", value);
			break;
		}
		case 2:
		{
			int a = 1, b = 2;
			ft_swap(&a, &b);
			printf ("%d %d", a, b);
			break;
		}
		case 3:
		{
			int	div, mod;
			ft_div_mod(33, 5, &div, &mod);
			printf ("%d %d", div, mod);
			break;
		}
		case 4:
		{
			int a = 33, b = 5;
			ft_ultimate_div_mod(&a, &b);
			printf ("%d %d", a, b);
			break;
		}
		case 5:
			ft_putstr("Stringsinhz marota\nasdf sadfklds\n213412\nzcxvc xzvx\n");
			break;
		case 6:
			printf ("%d", ft_strlen("asdf sadfklds\n213412\nzcxvc xzvx\n"));
			break;
		case 7:
		{
			int	i = 0, mat[] = {1, 2, 3, 4, 5};
			ft_rev_int_tab(mat, 5);
			while (i < 5)
				printf("%d ", mat[i++]);
			break;
		}
		case 8:
		{
			int	i = 0, mat[] = {9, 5, 3, 7, 2};
			ft_sort_int_tab(mat, 5);
			while (i < 5)
				printf("%d ", mat[i++]);
			break;
		}
	}
	
	
}

int	main (int argc, char **argv)
{
	if (argc == 2)
		run_ex (**(++argv) - '0');
	return (0);
}
