void	ft_rev_int_tab(int *tab, int size)
{
	int	aux;
	int	*p;

	p = tab + size - 1;
	while (tab < p)
	{
		aux = *tab;
		*tab = *p;
		*p = aux;
		tab++;
		p--;
	}
}
