#!/bin/bash
echo "ls -tump" > midLS
sh midLS
