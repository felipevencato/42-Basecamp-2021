#!/bin/bash
echo Z > z
cat z
