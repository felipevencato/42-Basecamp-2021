#!/bin/sh
find -type f,d | wc -l
