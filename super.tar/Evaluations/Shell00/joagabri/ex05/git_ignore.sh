#!/bin/sh
git ls-files --ignored -o --exclude-standard
