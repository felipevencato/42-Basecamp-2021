#!/bin/sh

awk -F : -v begin=$FT_LINE1 -v end=$FT_LINE2 \
'NR >= begin && NR <= end && NR % 2 == 0{print $1}' /etc/passwd | \
rev | sort -r | \
awk '{users=users", "$1}END{users=users".";sub(/, /,"",users);printf ("%s",users)}'
