#!/bin/sh
cat /etc/passwd \
| sed '/^#.*/d' \
| sed -n 'n;p' \
| rev \
| cut -d ':' -f7- \
| sort -r \
| sed -n "${FT_LINE1},${FT_LINE2}p" \
| sed -nr '{s/$/, /p}' \
| tr -d '\n' \
| sed -nr '{s/, $/./p}'
