#!/bin/sh
git ls-files -oi --exclude-standard
