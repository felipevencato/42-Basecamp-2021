void	ft_rev_int_tab(int *tab, int size)
{
	int	aux;
	int	i;

	if (size <= 0)
		return ;
	i = -1;
	while (i++ <= size--)
	{
		aux = tab[i];
		tab[i] = tab[size];
		tab[size] = aux;
	}
}
