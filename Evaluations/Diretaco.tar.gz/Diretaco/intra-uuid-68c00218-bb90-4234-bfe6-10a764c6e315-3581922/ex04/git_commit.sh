#!/bin/sh
git log -s --pretty=%H -5
