#include <unistd.h>
void	ft_print_pair (int number)
{
	char	txt[2];

	txt[0] = (number / 10) + '0';
	txt[1] = (number % 10) + '0';
	write (1, txt, 2);
}

void	ft_print_comb2 (void)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < 99)
	{
		while (j < 100)
		{
			if (i != j)
			{
				ft_print_pair (i);
				write (1, " ", 1);
				ft_print_pair (j);
				if (i + j != 98 + 99)
					write (1, ", ", 2);
			}
			j++;
		}
		j = ++i;
	}
}
